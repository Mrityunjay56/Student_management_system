package com.sms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sms.entities.Student;
import com.sms.service.StudentService;

@RestController
public class StudentController 
{
	@Autowired
	StudentService studentService;
 //@PostMapping("/api/createStudent")
 //Student createStudent(@RequestBody Student student)
 //{
	//return studentService.createStudent(student); 
 //}
 @PostMapping("/api/createStudent")
 ResponseEntity<Student> createStudent(@RequestBody Student student)
 {
	return new ResponseEntity<Student>(studentService.createStudent(student),HttpStatus.CREATED); 
 }
 @GetMapping("/api/getAllStudents")
 List<Student> getAllStudents()
 {
	 return studentService.getAllStudents();
 }
 @GetMapping("/api/getStudentById/{id}")
 Student getStudentById(@PathVariable int id)
 {
	 return studentService.getStudentById(id);
 }
}
