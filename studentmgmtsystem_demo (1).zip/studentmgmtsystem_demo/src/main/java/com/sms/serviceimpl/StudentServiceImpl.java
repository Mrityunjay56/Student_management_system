package com.sms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.entities.Student;
import com.sms.repository.StudentRepository;
import com.sms.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService
{
	@Autowired
	StudentRepository studentRepository;
  public Student createStudent(Student student)
  {
	  return studentRepository.save(student);
  }
@Override
public List<Student> getAllStudents() {
	
	return studentRepository.findAll();
}
@Override
public Student getStudentById(int id) {
	Student s=studentRepository.findById(id).get();
	return s;
}
//@Override
//public Student updateStudent(int id, Student student) {
	//Student s=studentRepository.findById(id).get();
	//s.setName(student.getName());
//}
}
