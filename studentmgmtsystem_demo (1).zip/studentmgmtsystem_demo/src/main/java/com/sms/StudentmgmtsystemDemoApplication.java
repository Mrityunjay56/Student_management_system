package com.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentmgmtsystemDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentmgmtsystemDemoApplication.class, args);
	}

}
